#!/usr/bin/env python3
"""
SD Trading System - AmiBroker Multi-Symbol Live Feed Bridge
============================================================
File    : SD_LiveFeed_Reader.py
Replaces: fyers_bridge.py

PURPOSE
-------
Replaces the single-symbol Fyers WebSocket feed with a multi-symbol
AmiBroker-driven feed. AmiBroker AFL (SD_LiveFeed_Export.afl) writes
one <SYMBOL>.csv per symbol into WATCH_DIR. This script:

  1. Discovers all symbol CSVs in WATCH_DIR (or a configured whitelist)
  2. Tails only NEW rows appended since last read (no re-processing)
  3. Validates each row (9-column format, numeric checks)
  4. Appends clean rows to ENGINE_DIR/<SYMBOL>.csv
  5. Writes a JSON status file (bridge_status.json) matching the old format
  6. Rotates logs (5 MB x 5 files)

OUTPUT FORMAT (identical to SD Engine expectation)
---------------------------------------------------
Timestamp,DateTime,Symbol,Open,High,Low,Close,Volume,OpenInterest
1774237500,2026-03-23 09:15:00,NIFTY-FUT,22821.00,22821.00,22645.80,22700.00,838435,17302870

USAGE
-----
  python SD_LiveFeed_Reader.py                          # uses config.ini in same dir
  python SD_LiveFeed_Reader.py --config /path/to/cfg    # explicit config path
  python SD_LiveFeed_Reader.py --watch-dir D:/... --engine-dir D:/... --timeframe 5

CONFIG FILE (config.ini)
------------------------
[LiveFeed]
watch_dir    = D:\\SD_System\\LiveFeed\\Data
engine_dir   = D:\\SD_System\\EngineData
timeframe    = 5
poll_sec     = 2
symbols      =                          ; blank = ALL symbols found in watch_dir
log_dir      = D:\\SD_System\\Logs
log_level    = INFO
status_file  = D:\\SD_System\\Logs\\bridge_status.json
"""

import os
import sys
import time
import json
import signal
import logging
import logging.handlers
import argparse
import configparser
from pathlib import Path
from datetime import datetime
from typing import Dict, List, Optional

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

EXPECTED_COLUMNS = 9
CSV_HEADER       = "Timestamp,DateTime,Symbol,Open,High,Low,Close,Volume,OpenInterest"

DEFAULT_WATCH_DIR  = r"D:\SD_System\LiveFeed\Data"
DEFAULT_ENGINE_DIR = r"D:\SD_System\EngineData"
DEFAULT_LOG_DIR    = r"D:\SD_System\Logs"
DEFAULT_STATUS     = r"D:\SD_System\Logs\bridge_status.json"
DEFAULT_TIMEFRAME  = 5      # minutes (informational / logging only)
DEFAULT_POLL_SEC   = 2.0    # seconds between directory scans
DEFAULT_SYMBOLS: List[str] = []   # empty = auto-discover ALL

# ---------------------------------------------------------------------------
# Logging  (same rotating pattern as fyers_bridge)
# ---------------------------------------------------------------------------

def setup_logger(log_dir: str, level: str = "INFO") -> logging.Logger:
    os.makedirs(log_dir, exist_ok=True)
    log_path = os.path.join(log_dir, "sd_livefeed.log")

    logger = logging.getLogger("SDLiveFeed")
    logger.setLevel(getattr(logging, level.upper(), logging.INFO))

    fmt = logging.Formatter(
        "%(asctime)s [%(levelname)-7s] %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S"
    )

    fh = logging.handlers.RotatingFileHandler(
        log_path, maxBytes=5 * 1024 * 1024, backupCount=5, encoding="utf-8"
    )
    fh.setFormatter(fmt)

    ch = logging.StreamHandler(sys.stdout)
    ch.setFormatter(fmt)

    logger.addHandler(fh)
    logger.addHandler(ch)
    return logger


# ---------------------------------------------------------------------------
# Per-symbol state  (mirrors last_written_ts in fyers_bridge.FyersBridgeService)
# ---------------------------------------------------------------------------

class SymbolState:
    """
    Tracks byte read position and last-written bar timestamp for one symbol.

    read_offset  : byte position in the AmiBroker source CSV after last tail.
                   Initialised to current EOF so historical rows are skipped
                   on first startup (matches fyers_bridge resumption behaviour).
    last_ts      : Unix timestamp of the last bar successfully written to the
                   engine file. Seeded from the last data line of the engine
                   CSV on startup (same as fyers_bridge.load_last_timestamp).
    rows_written : running count for status/logging.
    """

    def __init__(self, symbol: str, src_path: str, engine_path: str):
        self.symbol       = symbol
        self.src_path     = src_path
        self.engine_path  = engine_path
        self.read_offset  = 0
        self.last_ts: Optional[int] = None
        self.rows_written = 0

    # -- Mirrors fyers_bridge.FyersBridgeService.load_last_timestamp() -------
    def load_last_timestamp(self) -> Optional[int]:
        """Read the last Unix timestamp from the engine CSV tail."""
        ep = Path(self.engine_path)
        if not ep.exists():
            return None
        try:
            last_data_line = None
            with open(ep, "r", encoding="utf-8") as f:
                for line in f:
                    stripped = line.strip()
                    if stripped and not stripped.startswith("Timestamp"):
                        last_data_line = stripped
            if not last_data_line:
                return None
            return int(float(last_data_line.split(",")[0]))
        except Exception:
            return None

    def ensure_engine_file(self, logger: logging.Logger):
        """Create engine CSV with header if it does not exist yet."""
        ep = Path(self.engine_path)
        ep.parent.mkdir(parents=True, exist_ok=True)
        if not ep.exists():
            with open(ep, "w", encoding="utf-8") as f:
                f.write(CSV_HEADER + "\n")
            logger.info(f"  [{self.symbol}] Created engine file: {self.engine_path}")

    def init_from_disk(self, logger: logging.Logger):
        """
        Called once when symbol is first discovered:
          - Creates engine file if absent
          - Seeds last_ts from engine file tail (skip already-written bars)
          - Sets read_offset to current EOF of source (skip existing history)
        """
        self.ensure_engine_file(logger)
        self.last_ts = self.load_last_timestamp()

        try:
            self.read_offset = os.path.getsize(self.src_path)
        except OSError:
            self.read_offset = 0

        ts_str = (
            datetime.fromtimestamp(self.last_ts).strftime("%Y-%m-%d %H:%M:%S")
            if self.last_ts else "none"
        )
        logger.info(
            f"  [{self.symbol}] Tracking started | "
            f"last_ts={ts_str} | src_offset={self.read_offset}"
        )


# ---------------------------------------------------------------------------
# Row validation
# ---------------------------------------------------------------------------

def validate_row(raw: str) -> Optional[str]:
    """
    Validate a raw CSV line from the AmiBroker-written source file.
    Returns the cleaned 9-column string if valid, None otherwise.

    Rejects:
      - Blank lines
      - Header rows (starts with 'Timestamp')
      - Wrong column count (not 9)
      - Non-numeric Timestamp, Open, High, Low, Close, Volume, OpenInterest
      - Empty DateTime or Symbol fields
    """
    line = raw.strip()
    if not line or line.startswith("Timestamp"):
        return None

    parts = line.split(",")
    if len(parts) != EXPECTED_COLUMNS:
        return None

    try:
        float(parts[0])           # Timestamp (Unix epoch)
        if not parts[1].strip():  # DateTime
            return None
        if not parts[2].strip():  # Symbol
            return None
        float(parts[3])           # Open
        float(parts[4])           # High
        float(parts[5])           # Low
        float(parts[6])           # Close
        float(parts[7])           # Volume
        float(parts[8])           # OpenInterest
    except (ValueError, IndexError):
        return None

    return line


# ---------------------------------------------------------------------------
# Status file  (same JSON shape as fyers_bridge.update_status)
# ---------------------------------------------------------------------------

def write_status(status_path: str, payload: dict, logger: logging.Logger):
    try:
        Path(status_path).parent.mkdir(parents=True, exist_ok=True)
        payload["timestamp"] = datetime.now().isoformat()
        with open(status_path, "w", encoding="utf-8") as f:
            json.dump(payload, f, indent=2)
    except Exception as e:
        logger.error(f"Status write error: {e}")


# ---------------------------------------------------------------------------
# Core bridge
# ---------------------------------------------------------------------------

class AmiBrokerBridge:
    """
    Multi-symbol live feed bridge.
    Replaces FyersBridgeService.start_file_bridge() with AmiBroker as source.
    """

    def __init__(self, cfg: dict, logger: logging.Logger):
        self.watch_dir   = Path(cfg["watch_dir"])
        self.engine_dir  = Path(cfg["engine_dir"])
        self.timeframe   = cfg["timeframe"]
        self.poll_sec    = cfg["poll_sec"]
        self.whitelist   = cfg["symbols"]        # empty = all symbols
        self.status_path = cfg["status_file"]
        self.logger      = logger

        self.states: Dict[str, SymbolState] = {}
        self.running = False

        self.engine_dir.mkdir(parents=True, exist_ok=True)

    # ------------------------------------------------------------------
    # Symbol discovery
    # ------------------------------------------------------------------

    def _discover(self):
        """Scan watch_dir for new <SYMBOL>.csv files and register them."""
        if not self.watch_dir.exists():
            self.logger.warning(f"Watch dir not found: {self.watch_dir}")
            return

        for csv_file in sorted(self.watch_dir.glob("*.csv")):
            symbol = csv_file.stem.upper()

            # Skip internal AFL state/meta files (underscore prefix convention
            # used by SD_LiveFeed_Export.afl for _SD_State files)
            if symbol.startswith("_"):
                continue

            # Honour explicit whitelist if configured
            if self.whitelist and symbol not in self.whitelist:
                continue

            if symbol not in self.states:
                engine_path = str(self.engine_dir / f"{symbol}.csv")
                state = SymbolState(symbol, str(csv_file), engine_path)
                state.init_from_disk(self.logger)
                self.states[symbol] = state
                self.logger.info(f"New symbol registered: {symbol}")

    # ------------------------------------------------------------------
    # Per-symbol tail-and-write
    # ------------------------------------------------------------------

    def _process(self, state: SymbolState):
        """
        Tail new bytes from the AmiBroker source CSV, validate each row,
        deduplicate against last_ts, and append to the engine CSV.
        """
        try:
            current_size = os.path.getsize(state.src_path)
        except OSError:
            return   # file briefly locked by AFL write — skip this cycle

        if current_size <= state.read_offset:
            return   # nothing appended since last poll

        new_rows: List[str] = []

        try:
            with open(state.src_path, "r", encoding="utf-8") as f:
                f.seek(state.read_offset)
                for raw in f:
                    clean = validate_row(raw)
                    if not clean:
                        continue

                    # Deduplicate: skip bars already in engine file
                    # Mirrors: new_candles = [c for c in candles if int(c[0]) > last_written_ts]
                    bar_ts = int(float(clean.split(",")[0]))
                    if state.last_ts is not None and bar_ts <= state.last_ts:
                        continue

                    new_rows.append(clean)

                state.read_offset = f.tell()  # advance past bytes just read
        except OSError as e:
            self.logger.error(f"[{state.symbol}] Read error: {e}")
            return

        if not new_rows:
            return

        # Append validated rows to engine CSV
        try:
            with open(state.engine_path, "a", encoding="utf-8") as ef:
                for row in new_rows:
                    ef.write(row + "\n")
        except OSError as e:
            self.logger.error(f"[{state.symbol}] Engine write error: {e}")
            return

        # Update tracking state — mirrors: self.last_written_ts = int(new_candles[-1][0])
        last_row        = new_rows[-1]
        state.last_ts   = int(float(last_row.split(",")[0]))
        state.rows_written += len(new_rows)

        last_dt = last_row.split(",")[1]
        self.logger.info(
            f"[{state.symbol}] +{len(new_rows)} bar(s) | "
            f"total={state.rows_written} | last_bar={last_dt}"
        )

    # ------------------------------------------------------------------
    # Main loop
    # ------------------------------------------------------------------

    def run(self):
        self.logger.info("=" * 60)
        self.logger.info("SD AmiBroker Live Feed Bridge STARTED")
        self.logger.info(f"  Watch dir   : {self.watch_dir}")
        self.logger.info(f"  Engine dir  : {self.engine_dir}")
        self.logger.info(f"  Timeframe   : {self.timeframe} min")
        self.logger.info(f"  Poll sec    : {self.poll_sec}s")
        self.logger.info(f"  Symbols     : {self.whitelist if self.whitelist else 'ALL'}")
        self.logger.info(f"  Status file : {self.status_path}")
        self.logger.info("=" * 60)

        write_status(self.status_path, {"status": "starting"}, self.logger)

        self.running = True

        try:
            while self.running:
                # 1. Pick up any new symbol CSVs AmiBroker has created
                self._discover()

                # 2. Process each tracked symbol
                for state in list(self.states.values()):
                    self._process(state)

                # 3. Write status JSON (matches fyers_bridge format)
                symbols_status = {
                    sym: {
                        "last_ts": s.last_ts,
                        "last_dt": (
                            datetime.fromtimestamp(s.last_ts).strftime("%Y-%m-%d %H:%M:%S")
                            if s.last_ts else None
                        ),
                        "rows_written": s.rows_written,
                    }
                    for sym, s in self.states.items()
                }
                write_status(self.status_path, {
                    "status":    "running",
                    "timeframe": self.timeframe,
                    "symbols":   symbols_status,
                }, self.logger)

                time.sleep(self.poll_sec)

        except KeyboardInterrupt:
            self.logger.info("Received shutdown signal (Ctrl+C)")
        except Exception as e:
            self.logger.exception(f"Unhandled exception: {e}")
            write_status(self.status_path, {"status": "error", "message": str(e)},
                         self.logger)
            raise
        finally:
            self.running = False
            write_status(self.status_path, {"status": "stopped"}, self.logger)
            self.logger.info("SD AmiBroker Live Feed Bridge STOPPED")

    def stop(self):
        self.logger.info("Stop requested.")
        self.running = False


# ---------------------------------------------------------------------------
# Config loading  (mirrors system_config.load_config() pattern)
# ---------------------------------------------------------------------------

def load_config(config_path: Optional[str]) -> dict:
    cfg = {
        "watch_dir":   DEFAULT_WATCH_DIR,
        "engine_dir":  DEFAULT_ENGINE_DIR,
        "timeframe":   DEFAULT_TIMEFRAME,
        "poll_sec":    DEFAULT_POLL_SEC,
        "symbols":     list(DEFAULT_SYMBOLS),
        "log_dir":     DEFAULT_LOG_DIR,
        "log_level":   "INFO",
        "status_file": DEFAULT_STATUS,
    }

    # Auto-locate config.ini next to this script if none specified
    if not config_path:
        local = Path(__file__).parent / "config.ini"
        if local.exists():
            config_path = str(local)

    if config_path and Path(config_path).exists():
        cp = configparser.ConfigParser()
        cp.read(config_path, encoding="utf-8")
        sec = "LiveFeed"
        if cp.has_section(sec):

            def _get(key, cast=str):
                if cp.has_option(sec, key):
                    raw = cp.get(sec, key).strip()
                    return cast(raw) if raw else None
                return None

            cfg["watch_dir"]   = _get("watch_dir")          or cfg["watch_dir"]
            cfg["engine_dir"]  = _get("engine_dir")         or cfg["engine_dir"]
            cfg["timeframe"]   = _get("timeframe", int)     or cfg["timeframe"]
            cfg["poll_sec"]    = _get("poll_sec",  float)   or cfg["poll_sec"]
            cfg["log_dir"]     = _get("log_dir")             or cfg["log_dir"]
            cfg["log_level"]   = _get("log_level")           or cfg["log_level"]
            cfg["status_file"] = _get("status_file")         or cfg["status_file"]

            raw_sym = _get("symbols") or ""
            cfg["symbols"] = [
                s.strip().upper() for s in raw_sym.split(",") if s.strip()
            ]

    return cfg


# ---------------------------------------------------------------------------
# CLI argument parsing
# ---------------------------------------------------------------------------

def parse_args():
    p = argparse.ArgumentParser(
        description="SD Trading System - AmiBroker Multi-Symbol Live Feed Bridge",
        formatter_class=argparse.RawDescriptionHelpFormatter
    )
    p.add_argument("--config",       default=None, metavar="PATH",
                   help="Path to config.ini (default: config.ini next to script)")
    p.add_argument("--watch-dir",    default=None, metavar="DIR",
                   help="AmiBroker AFL output directory")
    p.add_argument("--engine-dir",   default=None, metavar="DIR",
                   help="SD Engine input directory")
    p.add_argument("--timeframe",    type=int,   default=None, metavar="MIN",
                   help="Bar timeframe in minutes (informational)")
    p.add_argument("--poll-sec",     type=float, default=None, metavar="SEC",
                   help="Poll interval in seconds (default: 2)")
    p.add_argument("--symbols",      default=None, metavar="LIST",
                   help="Comma-separated symbol list; blank = all")
    p.add_argument("--log-dir",      default=None, metavar="DIR")
    p.add_argument("--log-level",    default=None,
                   choices=["DEBUG", "INFO", "WARNING", "ERROR"])
    p.add_argument("--status-file",  default=None, metavar="PATH",
                   help="Path for bridge_status.json")
    return p.parse_args()


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------

def main():
    args = parse_args()
    cfg  = load_config(args.config)

    # CLI values override config file (same precedence as fyers_bridge)
    if args.watch_dir:   cfg["watch_dir"]   = args.watch_dir
    if args.engine_dir:  cfg["engine_dir"]  = args.engine_dir
    if args.timeframe:   cfg["timeframe"]   = args.timeframe
    if args.poll_sec:    cfg["poll_sec"]    = args.poll_sec
    if args.log_dir:     cfg["log_dir"]     = args.log_dir
    if args.log_level:   cfg["log_level"]   = args.log_level
    if args.status_file: cfg["status_file"] = args.status_file
    if args.symbols:
        cfg["symbols"] = [
            s.strip().upper() for s in args.symbols.split(",") if s.strip()
        ]

    logger = setup_logger(cfg["log_dir"], cfg["log_level"])

    bridge = AmiBrokerBridge(cfg, logger)

    # Graceful shutdown on SIGINT/SIGTERM — mirrors fyers_bridge signal_handler
    def _shutdown(sig, frame):
        logger.info(f"Signal {sig} received — shutting down gracefully")
        bridge.stop()

    signal.signal(signal.SIGINT,  _shutdown)
    signal.signal(signal.SIGTERM, _shutdown)

    try:
        bridge.run()
    except Exception as e:
        logger.error(f"Fatal error: {e}", exc_info=True)
        sys.exit(1)


if __name__ == "__main__":
    main()
